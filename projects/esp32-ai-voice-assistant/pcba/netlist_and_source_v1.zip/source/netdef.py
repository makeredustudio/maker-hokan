# -*- coding: utf-8 -*-
"""Full netlist definition for ESP32-S3 AI chatbot (xiaozhi bread-compact-wifi-s3cam pin map).
Each part: ref, lib symbol name, value, lcsc, dnp, group, {pin_number: net or None(NC)}"""
NC=None
G="GND"; V3="3V3"; VS="VSYS"; VB="VBUS"; BAT="VBAT"; A28="CAM_2V8"; D12="CAM_1V2"

def R(ref,sym,val,lcsc,a,b,group,dnp=False): return (ref,sym,val,lcsc,dnp,group,{"1":a,"2":b})
def C(ref,sym,val,lcsc,a,b,group): return (ref,sym,val,lcsc,False,group,{"1":a,"2":b})

R10K=("0402WGF1002TCE","10k","C25744"); R100K=("0402WGF1003TCE","100k","C25741"); R1K=("0402WGF1001TCE","1k","C11702")
R5K1=("0402WGF5101TCE","5.1k","C25905"); R470=("0402WGF4700TCE","470R","C25117"); R2K=("0402WGF2001TCE","2k","C4109")
R4K7=("0402WGF4701TCE","4.7k","C25900"); R22=("0402WGF220JTCE","22R","C25092"); R1M=("0402WGF1004TCE","1M","C26083"); R0=("0402WGF0000TCE","0R","C17168")
C100N=("CL05B104KO5NNNC","100nF","C1525"); C1U=("CL05A105KA5NQNC","1uF","C52923"); C10U=("CL21A106KAYNNNE","10uF","C15850"); C22U=("CL21A226MAQNNNE","22uF","C45783")
def r(ref,t,a,b,g,dnp=False): return R(ref,t[0],t[1]+(" DNP" if dnp else ""),t[2],a,b,g,dnp)
def c(ref,t,a,b,g): return C(ref,t[0],t[1],t[2],a,b,g)

# ESP32-S3-WROOM-1 module pins (number -> net)
U1 = {"1":G,"40":G,"41":G,"2":V3,"3":"EN",
 "4":"CAM_SIOD","5":"CAM_SIOC","6":"CAM_VSYNC","7":"CAM_HREF","8":"CAM_XCLK_MCU",
 "9":"CAM_D7","10":"CAM_D6","11":"CAM_D5","12":"CAM_D2","13":"LCD_SCL","14":"LCD_SDA",
 "15":"GPIO3","16":"GPIO46","17":"CAM_D1","18":"CAM_D3","19":"CAM_D0","20":"CAM_D4",
 "21":"CAM_PCLK_MCU","22":"LAMP_GPIO14","23":"LCD_RES","24":"LCD_DC","25":"RGB_LED_GPIO48",
 "26":"LCD_CS","27":"IO0","28":NC,"29":NC,"30":NC,"31":"LCD_BL_PWM",
 "32":"SPK_DIN","33":"SPK_BCLK","34":"SPK_LRCK","35":"MIC_SD","36":"U0RXD","37":"U0TXD",
 "38":"MIC_SCK","39":"MIC_WS"}

PARTS = [
 # ---------------- Core
 ("U1","ESP32-S3-WROOM-1","ESP32-S3-WROOM-1-N16R8","C2913202",False,"core",U1),
 c("C1",C22U,V3,G,"core"), c("C2",C10U,V3,G,"core"), c("C3",C100N,V3,G,"core"),
 r("R1",R10K,V3,"EN","core"), c("C4",C1U,"EN",G,"core"), r("R2",R10K,V3,"IO0","core"),
 ("SW1","TS-1187A-B-A-B","BOOT","C318884",False,"core",{"1":"IO0","2":"IO0","3":G,"4":G}),
 ("SW2","TS-1187A-B-A-B","RESET","C318884",False,"core",{"1":"EN","2":"EN","3":G,"4":G}),
 # ---------------- USB / UART
 ("J1","TYPE-C-31-M-12","USB-C","C165948",False,"usb",
   {"A1B12":G,"B1A12":G,"A4B9":VB,"B4A9":VB,"A5":"CC1","B5":"CC2","A6":"USB_DP","B6":"USB_DP",
    "A7":"USB_DN","B7":"USB_DN","A8":NC,"B8":NC,"1":G,"2":G,"3":G,"4":G}),
 r("R3",R5K1,"CC1",G,"usb"), r("R4",R5K1,"CC2",G,"usb"),
 # USBLC6-2SC6: 1=I/O1 2=GND 3=I/O2 4=I/O2 5=VBUS 6=I/O1
 ("U2","USBLC6-2SC6","USBLC6-2SC6","C7519",False,"usb",{"1":"USB_DP","6":"USB_DP","3":"USB_DN","4":"USB_DN","2":G,"5":VB}),
 ("U3","CH340C","CH340C","C84681",False,"usb",
   {"1":G,"2":"U0RXD","3":"CH_RXD","4":V3,"5":"USB_DP","6":"USB_DN","7":NC,"8":NC,"9":NC,"10":NC,
    "11":NC,"12":NC,"13":"DTR","14":"RTS","15":NC,"16":V3}),
 c("C5",C100N,V3,G,"usb"),
 ("Q1","MMBT3904-C20526","MMBT3904","C20526",False,"usb",{"1":"Q1_B","2":"RTS","3":"EN"}),
 ("Q2","MMBT3904-C20526","MMBT3904","C20526",False,"usb",{"1":"Q2_B","2":"DTR","3":"IO0"}),
 r("R5",R10K,"DTR","Q1_B","usb"), r("R6",R10K,"RTS","Q2_B","usb"),
 r("R7",R470,"U0TXD","CH_RXD","usb"),
 # ---------------- Power
 ("D1","SS34_C8678","SS34","C8678",False,"power",{"2":VB,"1":VS}),
 ("U4","TP4056","TP4056","C16581",False,"power",{"1":G,"2":"PROG","3":G,"4":VB,"5":BAT,"6":"STDBY_N","7":"CHRG_N","8":VB,"9":G}),
 r("R8",R2K,"PROG",G,"power"), c("C6",C10U,VB,G,"power"), c("C7",C10U,BAT,G,"power"),
 ("LED1","KT-0603R","RED CHRG","C2286",False,"power",{"1":"LED1_A","2":"CHRG_N"}),          # 1=A 2=K
 ("LED2","0603Green509-620mcd","GREEN STDBY","C12624",False,"power",{"2":"LED2_A","1":"STDBY_N"}), # 2=A 1=K
 r("R9",R1K,VB,"LED1_A","power"), r("R10",R1K,VB,"LED2_A","power"),
 ("Q3","AO3401A","AO3401A","C15127",False,"power",{"1":VB,"2":VS,"3":BAT}),   # G S D
 r("R11",R100K,VB,G,"power"),
 ("J2","S2B-PH-SM4-TB","BATTERY","C295747",False,"power",{"1":BAT,"2":G,"3":NC,"4":NC}),
 ("SW3","MSK12C02","POWER","C431540",False,"power",{"1":VS,"2":"LDO_EN","3":NC,"4":NC}),
 r("R12",R100K,"LDO_EN",G,"power"),
 ("U5","ME6217C33M5G","ME6217C33","C427602",False,"power",{"1":VS,"2":G,"3":"LDO_EN","4":NC,"5":V3}),
 c("C8",C10U,VS,G,"power"), c("C9",C22U,V3,G,"power"),
 # ---------------- Camera (J3 order = ESP32-CAM, pin1=Y0)
 ("J3","05A20L24P","OV2640 FPC 24P","C5362158",False,"camera",
   {"1":NC,"2":NC,"3":"CAM_D2","4":"CAM_D1","5":"CAM_D3","6":"CAM_D0","7":"CAM_D4","8":"CAM_PCLK",
    "9":"CAM_D5","10":G,"11":"CAM_D6","12":"CAM_XCLK","13":"CAM_D7","14":V3,"15":D12,"16":"CAM_HREF",
    "17":"CAM_PWDN","18":"CAM_VSYNC","19":"CAM_RESET","20":"CAM_SIOC","21":A28,"22":"CAM_SIOD","23":G,"24":NC,
    "25":NC,"26":NC}),
 ("U6","ME6211C28M5G","ME6211C28","C53099",False,"camera",{"1":V3,"2":G,"3":V3,"4":NC,"5":A28}),
 ("U7","ME6211C12M5G-N","ME6211C12","C236672",False,"camera",{"1":V3,"2":G,"3":V3,"4":NC,"5":D12}),
 c("C10",C1U,V3,G,"camera"), c("C11",C1U,A28,G,"camera"), c("C12",C1U,V3,G,"camera"), c("C13",C1U,D12,G,"camera"),
 c("C14",C100N,V3,G,"camera"), c("C15",C100N,A28,G,"camera"), c("C16",C100N,D12,G,"camera"),
 r("R13",R4K7,V3,"CAM_SIOD","camera"), r("R14",R4K7,V3,"CAM_SIOC","camera"),
 r("R15",R10K,V3,"CAM_RESET","camera"), c("C17",C100N,"CAM_RESET",G,"camera"),
 r("R16",R10K,"CAM_PWDN",G,"camera"),
 r("R17",R22,"CAM_XCLK_MCU","CAM_XCLK","camera"), r("R18",R22,"CAM_PCLK","CAM_PCLK_MCU","camera"),
 # ---------------- Audio
 ("U8","ICS-43434_C5656610","ICS-43434","C5656610",False,"audio",{"1":"MIC_WS","2":G,"3":G,"4":"MIC_SCK","5":V3,"6":"MIC_SD"}),
 c("C18",C100N,V3,G,"audio"), r("R19",R100K,"MIC_SD",G,"audio"),
 ("U9","MAX98357AETE+T","MAX98357A","C910544",False,"audio",
   {"1":"SPK_DIN","2":"AMP_GAIN","3":G,"4":"AMP_SD_MODE","5":NC,"6":NC,"7":VS,"8":VS,"9":"SPK_P","10":"SPK_N",
    "11":G,"12":NC,"13":NC,"14":"SPK_LRCK","15":G,"16":"SPK_BCLK","17":G}),
 c("C19",C10U,VS,G,"audio"), c("C20",C100N,VS,G,"audio"),
 r("R20",R1M,V3,"AMP_SD_MODE","audio"), r("R21",R100K,"AMP_GAIN",G,"audio",dnp=True),
 ("J4","S2B-PH-SM4-TB","SPEAKER","C295747",False,"audio",{"1":"SPK_P","2":"SPK_N","3":NC,"4":NC}),
 # ---------------- Display
 ("J5","PM2.54-1X8PM-H85","LCD ST7789 1x8","C42431840",False,"display",
   {"1":G,"2":V3,"3":"LCD_SCL","4":"LCD_SDA","5":"LCD_RES","6":"LCD_DC","7":"LCD_CS","8":"LCD_BLK"}),
 ("Q4","MMBT3904-C20526","MMBT3904","C20526",False,"display",{"1":"Q4_B","2":G,"3":"Q5_G"}),
 ("Q5","AO3401A","AO3401A","C15127",False,"display",{"1":"Q5_G","2":V3,"3":"LCD_BLK"}),
 r("R22",R1K,"LCD_BL_PWM","Q4_B","display"), r("R23",R100K,"Q4_B",G,"display"),
 r("R24",R10K,V3,"Q5_G","display"), r("R25",R0,"LCD_BL_PWM","LCD_BLK","display",dnp=True),
 # ---------------- Status / expansion
 ("LED3","WS2812B-2020-V6","WS2812B-2020","C52917434",False,"misc",{"1":NC,"2":G,"3":"LED_DIN","4":V3}),
 c("C21",C100N,V3,G,"misc"), r("R26",R22,"RGB_LED_GPIO48","LED_DIN","misc"),
 ("J6","PZ254V-11-08P","EXPANSION DNP","C492407",True,"misc",
   {"1":V3,"2":G,"3":VS,"4":"LAMP_GPIO14","5":"GPIO3","6":"GPIO46","7":"U0TXD","8":"U0RXD"}),
]
GROUPS=[("power","POWER: USB-C 5V / TP4056 charger / power-path / 3V3 LDO"),
        ("usb","USB-UART CH340C + auto-download (DevKitC style)"),
        ("core","ESP32-S3-WROOM-1-N16R8 core"),
        ("camera","CAMERA OV2640 24P DVP (xiaozhi bread-compact-wifi-s3cam)"),
        ("audio","AUDIO: ICS-43434 I2S mic + MAX98357A I2S amp"),
        ("display","LCD ST7789 240x320 SPI + backlight"),
        ("misc","WS2812 status LED + expansion header")]
