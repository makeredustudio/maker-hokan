# Independent connectivity check of the KiCad 5 legacy .sch + .lib text (does not reuse generator code)
import re, sys, collections
sys.path.insert(0, '.')
from netdef import PARTS
lib = open('proj_v5/lib/LCSC.lib', encoding='utf-8').read()
pins = {}
for m in re.finditer(r'^DEF (\S+) .*?^ENDDEF', lib, re.S | re.M):
    pins[m.group(1)] = [(x.split()[2], int(x.split()[3]), int(x.split()[4])) for x in m.group(0).splitlines() if x.startswith('X ')]
sch = open('proj_v5/ESP32S3_AI_Chatbot.sch', encoding='utf-8').read().splitlines()
comps = []; wires = []; labels = []; ncs = []
i = 0
while i < len(sch):
    l = sch[i]
    if l == '$Comp':
        blk = []
        while sch[i] != '$EndComp': blk.append(sch[i]); i += 1
        sym, ref = blk[1].split()[1].split(':')[1], blk[1].split()[2]
        X, Y = map(int, blk[3].split()[1:3])
        mat = list(map(int, blk[-1].split()))
        lcsc = next(re.search(r'"([^"]*)"', b).group(1) for b in blk if b.endswith('"LCSC Part"'))
        comps.append((ref, sym, X, Y, mat, lcsc))
    elif l == 'Wire Wire Line':
        a = list(map(int, sch[i + 1].split())); wires.append(((a[0], a[1]), (a[2], a[3]))); i += 1
    elif l.startswith('Text Label'):
        a = l.split(); labels.append(((int(a[2]), int(a[3])), sch[i + 1].strip())); i += 1
    elif l.startswith('NoConn'):
        a = l.split(); ncs.append((int(a[2]), int(a[3])))
    i += 1
parent = {}
def f(x):
    parent.setdefault(x, x)
    while parent[x] != x: parent[x] = parent[parent[x]]; x = parent[x]
    return x
def u(a, b): parent[f(a)] = f(b)
for a, b in wires: u(('pt',) + a, ('pt',) + b)
for p, name in labels: u(('pt',) + p, ('net', name))
pinpt = {}
for ref, sym, X, Y, (a, b, c, d), lcsc in comps:
    for num, px, py in pins[sym]:
        # legacy transform: x' = X + a*px + b*py ; y' = Y + c*px + d*py
        pt = (X + a * px + b * py, Y + c * px + d * py)
        pinpt[(ref, num)] = pt
        u(('pin', ref, num), ('pt',) + pt)
ncset = set(ncs)
probs = []
groups = collections.defaultdict(set)
for k in list(parent):
    if k[0] == 'net': groups[f(k)].add(k[1])
for g, names in groups.items():
    if len(names) > 1: probs.append(f"nets merged: {names}")
partmap = {p[0]: p for p in PARTS}
if len(comps) != len(PARTS): probs.append(f"comp count {len(comps)} vs {len(PARTS)}")
for ref, sym, X, Y, mat, lcsc in comps:
    p = partmap[ref]
    if lcsc != p[3]: probs.append(f"{ref} lcsc")
    for num, net in p[6].items():
        pt = pinpt[(ref, num)]
        if net is None:
            if pt not in ncset: probs.append(f"{ref}.{num} NC flag missing")
            continue
        root = f(('pin', ref, num))
        if f(('net', net)) != root: probs.append(f"{ref}.{num} not on {net}")
print(f"v5 check: comps={len(comps)} wires={len(wires)} labels={len(labels)} noconn={len(ncs)} problems={len(probs)}")
for p in probs[:30]: print(" -", p)
