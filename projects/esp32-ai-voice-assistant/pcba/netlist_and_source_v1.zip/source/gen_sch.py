# -*- coding: utf-8 -*-
import re, uuid, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from netdef import PARTS, GROUPS

LIB = "LCSC"
SYMFILE = os.path.join(os.path.dirname(__file__), "proj/lib/LCSC.kicad_sym")
OUT = os.path.join(os.path.dirname(__file__), "proj/ESP32S3_AI_Chatbot.kicad_sch")
NS = uuid.UUID("6b1f0c1e-7d7a-4c55-9e0e-2f6a5d7f0a01")
def U(*k): return str(uuid.uuid5(NS, "/".join(map(str, k))))

# ---------- tiny s-expr parser
tok_re = re.compile(r'\s*(\(|\)|"(?:[^"\\]|\\.)*"|[^\s()"]+)')
def parse(s):
    pos = 0; stack = [[]]
    for m in tok_re.finditer(s):
        t = m.group(1)
        if t == '(':
            stack.append([])
        elif t == ')':
            x = stack.pop(); stack[-1].append(x)
        else:
            stack[-1].append(t)
    return stack[0][0]
def unq(t): return t[1:-1].replace('\\"', '"') if t.startswith('"') else t
def q(s): return '"' + str(s).replace('\\', '\\\\').replace('"', '\\"') + '"'
def dump(x, ind=0):
    if isinstance(x, str): return x
    # inline short lists
    inner = [dump(e, ind + 1) for e in x]
    one = "(" + " ".join(inner) + ")"
    if len(one) < 100 and "\n" not in one: return one
    sp = "  " * (ind + 1)
    return "(" + inner[0] + "".join("\n" + sp + e for e in inner[1:]) + ")"

raw = open(SYMFILE, encoding="utf-8").read()
tree = parse(raw)
SYMS = {}
for e in tree[1:]:
    if isinstance(e, list) and e[0] == 'symbol':
        SYMS[unq(e[1])] = e

def sym_info(name):
    e = SYMS[name]
    pins = {}; pts = []
    def walk(x):
        if not isinstance(x, list): return
        if x and x[0] == 'pin':
            at = next(y for y in x if isinstance(y, list) and y[0] == 'at')
            ln = next(y for y in x if isinstance(y, list) and y[0] == 'length')
            nm = next(y for y in x if isinstance(y, list) and y[0] == 'name')
            nu = next(y for y in x if isinstance(y, list) and y[0] == 'number')
            px, py, pa = float(at[1]), float(at[2]), int(float(at[3])) % 360
            n = unq(nu[1])
            pins.setdefault(n, []).append((px, py, pa, float(ln[1]), unq(nm[1])))
            pts.append((px, py))
            return
        if x and x[0] in ('start', 'end', 'xy', 'center') and len(x) >= 3:
            try: pts.append((float(x[1]), float(x[2])))
            except ValueError: pass
        for y in x: walk(y)
    walk(e)
    return pins, pts

# ---------- build lib_symbols copy with LCSC: prefix
def lib_symbol_copy(name):
    e = SYMS[name]
    c = [e[0], q(LIB + ":" + name)] + e[2:]
    return c

SNAP = 1.27
def snap(v): return round(round(v / SNAP) * SNAP, 4)

# ---------- layout
STUB = 2.54
def label_len(net): return 1.0 * len(net) + 3

placed = []   # (part, x, y, info)
items = []    # schematic items
sheet_w, sheet_h = 841.0, 594.0  # A1 landscape
MARGIN = 20.0

def part_extent(part):
    ref, sym, val, lcsc, dnp, grp, pmap = part
    pins, pts = sym_info(sym)
    # verify coverage
    missing = set(pins) - set(pmap); extra = set(pmap) - set(pins)
    if missing or extra:
        raise SystemExit(f"{ref} {sym}: missing {missing} extra {extra}")
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    l, r_, b, t = min(xs), max(xs), min(ys), max(ys)
    # label room per side
    L = R = T = B = 2.0
    for n, plist in pins.items():
        net = pmap[n]
        ext = STUB + (label_len(net) if net else 1)
        for (px, py, pa, ln, nm) in plist:
            if pa == 0: L = max(L, ext)
            elif pa == 180: R = max(R, ext)
            elif pa == 90: B = max(B, ext)
            else: T = max(T, ext)
    # extents relative to symbol origin in schematic coords (y down)
    return (l - L, -(t + T) - 3.5, r_ + R, -(b - B) + 3.5)

y_cursor = MARGIN + 10
x_cursor = MARGIN
row_h = 0
texts = []
for gkey, gtitle in GROUPS:
    gparts = [p for p in PARTS if p[5] == gkey]
    # group header
    if x_cursor > MARGIN:
        y_cursor += row_h + 9; x_cursor = MARGIN; row_h = 0
    texts.append((gtitle, MARGIN, y_cursor))
    y_cursor += 8
    for p in gparts:
        x0, y0, x1, y1 = part_extent(p)
        w, h = x1 - x0, y1 - y0
        if x_cursor + w > sheet_w - MARGIN:
            y_cursor += row_h + 4; x_cursor = MARGIN; row_h = 0
        ox = snap(x_cursor - x0); oy = snap(y_cursor - y0)
        placed.append((p, ox, oy))
        x_cursor += w + 6; row_h = max(row_h, h)
total_h = y_cursor + row_h + MARGIN
if total_h > sheet_h:
    print("WARNING: content height", total_h, "exceeds sheet", sheet_h)

# ---------- emit
out = []
out.append(['kicad_sch', ['version', '20211123'], ['generator', 'eeschema'], ['uuid', U('sheet')],
            ['paper', '"A1"'],
            ['title_block', ['title', q('ESP32-S3 AI Chatbot (xiaozhi bread-compact-wifi-s3cam pinout)')],
             ['date', q('2026-10-06')], ['rev', q('0.1-generated')],
             ['company', q('Maker Bu Wan Ji Hua')],
             ['comment', '1', q('Auto-generated from BOM/pin map. NOT built or tested. Check every footprint & FPC orientation.')],
             ['comment', '2', q('Symbols/footprints: LCSC/EasyEDA via easyeda2kicad. GPIO45 = LCD CS: NO pull-up (strapping).')]]])
sch = out[0]
used = sorted({p[1] for p in PARTS})
sch.append(['lib_symbols'] + [lib_symbol_copy(n) for n in used])

font = ['effects', ['font', ['size', '1.27', '1.27']]]
def fmt(v): return ('%.4f' % v).rstrip('0').rstrip('.')
connections = []  # (ref, pin, net, x, y) for self-check
instances = []
for (p, ox, oy) in placed:
    ref, sym, val, lcsc, dnp, grp, pmap = p
    pins, pts = sym_info(sym)
    su = U('sym', ref)
    xs = [pp[0] for pp in pts]; ys = [pp[1] for pp in pts]
    top = oy - max(ys); bot = oy - min(ys)
    fp = LIB + ":" + next(unq(x[2]) for x in SYMS[sym][2:] if isinstance(x, list) and x[0] == 'property' and unq(x[1]) == 'Footprint').split(':', 1)[-1]
    mpn = next((unq(x[2]) for x in SYMS[sym][2:] if isinstance(x, list) and x[0] == 'property' and unq(x[1]) == 'MPN'), sym)
    ds = next((unq(x[2]) for x in SYMS[sym][2:] if isinstance(x, list) and x[0] == 'property' and unq(x[1]) == 'Datasheet'), '')
    props = [("Reference", ref, ox, top - 3.81, False), ("Value", val, ox, bot + 3.81, False),
             ("Footprint", fp, ox, bot + 6.35, True), ("Datasheet", ds, ox, bot + 6.35, True),
             ("LCSC Part", lcsc, ox, bot + 6.35, True), ("LCSC", lcsc, ox, bot + 6.35, True),
             ("Supplier", "LCSC", ox, bot + 6.35, True), ("Supplier Part", lcsc, ox, bot + 6.35, True),
             ("MPN", mpn, ox, bot + 6.35, True)]
    if dnp: props.append(("DNP", "DNP (do not populate)", ox, bot + 6.35, False))
    s = ['symbol', ['lib_id', q(LIB + ":" + sym)], ['at', fmt(ox), fmt(oy), '0'], ['unit', '1'],
         ['in_bom', 'no' if dnp else 'yes'], ['on_board', 'yes'], ['uuid', su]]
    for i, (k, v, x, y, hide) in enumerate(props):
        eff = ['effects', ['font', ['size', '1.27', '1.27']]] + (['hide'] if hide else [])
        s.append(['property', q(k), q(v), ['id', str(i)], ['at', fmt(x), fmt(y), '0'], eff])
    for n, plist in pins.items():
        s.append(['pin', q(n), ['uuid', U('pin', ref, n)]])
    sch.append(s)
    instances.append(['path', q('/' + su), ['reference', q(ref)], ['unit', '1'], ['value', q(val)], ['footprint', q(fp)]])
    # wires + labels
    for n, plist in pins.items():
        net = pmap[n]
        for k, (px, py, pa, ln, nm) in enumerate(plist):
            ax, ay = round(ox + px, 4), round(oy - py, 4)
            if net is None:
                sch.append(['no_connect', ['at', fmt(ax), fmt(ay)], ['uuid', U('nc', ref, n, k)]])
                connections.append((ref, n, None, ax, ay)); continue
            dx, dy, la, just = {0: (-STUB, 0, '180', 'right'), 180: (STUB, 0, '0', 'left'),
                                90: (0, STUB, '270', 'right'), 270: (0, -STUB, '90', 'left')}[pa]
            bx, by = round(ax + dx, 4), round(ay + dy, 4)
            sch.append(['wire', ['pts', ['xy', fmt(ax), fmt(ay)], ['xy', fmt(bx), fmt(by)]],
                        ['stroke', ['width', '0'], ['type', 'default'], ['color', '0', '0', '0', '0']], ['uuid', U('w', ref, n, k)]])
            sch.append(['label', q(net), ['at', fmt(bx), fmt(by), la],
                        ['effects', ['font', ['size', '1.27', '1.27']], ['justify', just, 'bottom']], ['uuid', U('l', ref, n, k)]])
            connections.append((ref, n, net, ax, ay))
for (t, x, y) in texts:
    sch.append(['text', q(t), ['at', fmt(x), fmt(y), '0'], ['effects', ['font', ['size', '2.54', '2.54'], 'bold'], ['justify', 'left', 'bottom']], ['uuid', U('t', t)]])
notes = ["NOTES: (1) GPIO19/20 are used by LCD -> native USB unavailable; flash via CH340C (SW3 must be ON).",
         "(2) GPIO45 (LCD_CS) is a strapping pin: no pull-up on this net, check LCD module.",
         "(3) J3 FPC pin order = ESP32-CAM style (pin1=Y0). Verify against your OV2640 module + connector contact side.",
         "(4) R21, R25, J6 = DNP. Battery J2 polarity: pin1 = +, verify your battery lead."]
for i, t in enumerate(notes):
    sch.append(['text', q(t), ['at', fmt(MARGIN), fmt(sheet_h - 40 + i * 5), '0'], ['effects', ['font', ['size', '1.8', '1.8']], ['justify', 'left', 'bottom']], ['uuid', U('note', i)]])
sch.append(['sheet_instances', ['path', '"/"', ['page', '"1"']]])
sch.append(['symbol_instances'] + instances)
open(OUT, 'w', encoding='utf-8').write(dump(sch) + "\n")
import json
json.dump(connections, open(os.path.join(os.path.dirname(__file__), 'connections.json'), 'w'))
print("parts", len(placed), "pins", len(connections), "height", round(total_h, 1))
