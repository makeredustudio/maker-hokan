import zipfile, os, shutil
def zipdir(zpath, base, items):
    with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as z:
        for it in items:
            p = os.path.join(base, it)
            if os.path.isdir(p):
                for root, _, files in os.walk(p):
                    for f in sorted(files):
                        full = os.path.join(root, f); z.write(full, os.path.relpath(full, base))
            else: z.write(p, it)
shutil.rmtree('pkg', ignore_errors=True); os.makedirs('pkg')
zipdir('pkg/ESP32S3_AI_Chatbot_KiCad6_for_LCEDA.zip', 'proj', ['ESP32S3_AI_Chatbot.kicad_pro','ESP32S3_AI_Chatbot.kicad_sch','sym-lib-table','fp-lib-table','lib'])
zipdir('pkg/ESP32S3_AI_Chatbot_KiCad5_for_LCEDA.zip', 'proj_v5', ['ESP32S3_AI_Chatbot.pro','ESP32S3_AI_Chatbot.sch','ESP32S3_AI_Chatbot-cache.lib','sym-lib-table','fp-lib-table','lib'])
with zipfile.ZipFile('pkg/ESP32S3_AI_Chatbot_netlist_and_source.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for f in os.listdir('out/netlist'): z.write(f'out/netlist/{f}', f'netlist/{f}')
    for f in ['netdef.py','gen_sch.py','gen_v5.py','verify.py','verify_v5.py','build.sh','pack.py']: z.write(f, f'source/{f}')
    for f in ['ERC_report.txt','kicad_bom.csv','README_匯入立創EDA.md','net_report.csv']: z.write(f'out/{f}', f)
for f in ['ESP32S3_AI_Chatbot_schematic.pdf','net_report.csv','README_匯入立創EDA.md']: shutil.copy(f'out/{f}', 'pkg/')
for f in sorted(os.listdir('pkg')):
    print(f, os.path.getsize('pkg/'+f))
    if f.endswith('.zip'): print('   ', len(zipfile.ZipFile('pkg/'+f).namelist()), 'entries; test:', zipfile.ZipFile('pkg/'+f).testzip())
