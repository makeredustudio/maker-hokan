#!/bin/bash
set -e
cd /workspace/pcba/kicad
python3 gen_sch.py
cd proj
S=ESP32S3_AI_Chatbot.kicad_sch
kicad-cli sch erc --format report --severity-all -o ../out/ERC_report.txt $S | tail -1
mkdir -p ../out/netlist
kicad-cli sch export netlist --format kicadsexpr -o ../out/netlist/ESP32S3_AI_Chatbot_KiCad.net $S >/dev/null
kicad-cli sch export netlist --format pads -o /tmp/nl.asc $S >/dev/null
kicad-cli sch export netlist --format allegro -o /tmp/nl.tel $S >/dev/null
sed -E 's/LCSC://; s#^\*SIGNAL\* /#*SIGNAL* #' /tmp/nl.asc > ../out/netlist/ESP32S3_AI_Chatbot_PADS.asc
sed -E 's/lcsc_//I; s#^/##; s#\(Source: .*/#(Source: #' /tmp/nl.tel > ../out/netlist/ESP32S3_AI_Chatbot_Allegro.tel
kicad-cli sch export pdf -o ../out/ESP32S3_AI_Chatbot_schematic.pdf $S >/dev/null
kicad-cli sch export bom -o ../out/kicad_bom.csv --fields 'Reference,Value,Footprint,LCSC Part,${QUANTITY},${DNP}' --group-by 'Value,Footprint,LCSC Part' --ref-range-delimiter '' $S >/dev/null || true
cd ..
python3 verify.py | grep -v '^parts'
python3 gen_v5.py | grep -v '^parts'
rm -rf proj_v5/lib/LCSC.pretty && cp -r proj/lib/LCSC.pretty proj_v5/lib/
python3 verify_v5.py
