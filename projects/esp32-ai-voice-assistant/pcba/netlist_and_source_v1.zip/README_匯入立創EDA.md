# ESP32-S3 AI 聊天機械人：KiCad 原理圖（用嚟匯入立創 EDA）

更新：2026-10-06（HKT）｜腳位跟小智 `bread-compact-wifi-s3cam`（同 BOM、Pin Map 一致）

> ⚠ **老實講：我冇辦法開立創 EDA，所以「匯入立創 EDA」呢一步未試過。** 檔案已經喺 KiCad 9.0.2 入面開過、跑過 ERC，亦逐條網絡核對過，但匯入之後點樣顯示、封裝綁唔綁得到，要你自己開嚟睇。塊板仲未做過、未測試過。

---

## 1. 包含咩檔案

| 檔案 | 用途 |
|---|---|
| `ESP32S3_AI_Chatbot_KiCad6_for_LCEDA.zip` | **首選**。KiCad 6 格式工程（.kicad_pro + .kicad_sch + 符號庫 + 封裝庫），74 粒零件全部連好 |
| `ESP32S3_AI_Chatbot_KiCad5_for_LCEDA.zip` | **後備**。同一張圖嘅 KiCad 5.1 舊格式（.pro + .sch + .lib + cache.lib + 封裝）。官方文件寫明支援 5.1，如果首選匯入失敗就試呢個 |
| `ESP32S3_AI_Chatbot_schematic.pdf` | 原理圖預覽（A1） |
| `net_report.csv` | 每條網絡連去邊粒零件邊隻腳（68 條網絡 + 31 隻 NC 腳） |
| `ESP32S3_AI_Chatbot_netlist_and_source.zip` | PCB 用網表（PADS `.asc`、Allegro `.tel`、KiCad `.net`）、ERC 報告、KiCad BOM，同埋生成呢張圖嘅 Python 原始碼 |

所有符號同封裝都係用 `easyeda2kicad` 按 LCSC C 編號由立創/EasyEDA 官方庫下載，每粒零件都有 `LCSC Part`、`Supplier Part`、`LCSC` 屬性（例如 U1 = C2913202）。

## 2. 點樣匯入立創 EDA 專業版（建議次序）

### 路線 A：直接匯入 KiCad 工程 zip（最快）
1. 打開立創 EDA 專業版。
2. 喺**開始頁**揀匯入 KiCad（官方文件：「在专业版开始页进行导入」），揀 `ESP32S3_AI_Chatbot_KiCad6_for_LCEDA.zip`。
3. 匯入選項按官方文件揀（「導入文件」或「導入文件並提取庫」）。
4. 打開原理圖，跟第 4 節嘅清單檢查。

### 路線 B：KiCad 5 舊格式
如果路線 A 報錯或者零件唔見咗，用 `ESP32S3_AI_Chatbot_KiCad5_for_LCEDA.zip` 重做一次步驟 2–4。

### 路線 C：官方「格式轉換助手」（桌面程式）
官方建議用「嘉立创EDA文件迁移助手」。佢個 KiCad 支援列表包括 `.kicad_pro`、`.kicad_sch`、`.sch`、`.kicad_sym`、`.lib`、`.kicad_mod`。轉好之後喺立創 EDA 揀「文件 → 导入 → 嘉立创EDA（专业版）」。

### 路線 D：先用 KiCad 打包一次
官方文件提醒要用 **KiCad 自帶嘅打包（歸檔）功能**整 zip，唔好自己喺資料夾壓縮。如果 A–C 都唔得：
1. 裝 KiCad（免費），打開 zip 入面嘅 `ESP32S3_AI_Chatbot.kicad_pro`。
2. 用 KiCad 嘅歸檔工程功能打包成 zip。
3. 用嗰個 zip 再試路線 A。

### 只想直接整 PCB（唔要原理圖）
專業版支援「顶部菜单 → 文件 → 导入 → 网表」，格式 `.tel`、`.enet`、`.asc`、`.net`。可以試 `ESP32S3_AI_Chatbot_PADS.asc` 或 `ESP32S3_AI_Chatbot_Allegro.tel`（封裝名已經改成立創庫嘅名，例如 `SOT-23-5_L3.0-W1.7-P0.95-LS2.8-BL`）。⚠ 呢個方法只會喺 PCB 生成零件同飛線，**唔會有原理圖**，而且封裝配唔配得到都未試過。

## 3. 官方文件（我查過嘅）
- 專業版匯入 KiCad：<https://prodocs.lceda.cn/cn/import-export/import-kicad/>（寫明支援 KiCad 5.1、5.9；要用 KiCad 自帶打包功能）
- 格式轉換助手：<https://prodocs.lceda.cn/cn/import-export/easyeda-pro-format-converter/>
- 專業版匯入網表（入 PCB）：<https://prodocs.lceda.cn/cn/pcb/file-import-netlist/>
- 標準版匯入 KiCad：<https://docs.lceda.cn/cn/Import/Import-KiCAD/>（v4.06 以上；要整個工程連庫一齊 zip；警告 5.1.3 之後嘅格式可能匯入失敗）
- 專業版匯入 Altium（網絡名規則）：<https://prodocs.lceda.cn/cn/import-export/import-altium-designer/>（專業版網絡名只支援大寫英文；呢張圖所有網絡名已經係大寫）

⚠ 官方 KiCad 頁面只寫 5.1 同 5.9，冇明確講支援 KiCad 6/7/8。所以我揀咗最舊嘅 S-expression 格式（KiCad 6.0，`version 20211123`），另外再整一份 5.1 舊格式做後備。

## 4. 匯入之後一定要檢查
1. **零件數量 74 粒**（包括 DNP 嘅 R21、R25、J6），網絡 68 條。可以用 `net_report.csv` 抽查。
2. **封裝有冇綁定**：特別係 U1（WIRELM-SMD_ESP32-S3-WROOM-1）、U9 TQFN-16、J1 USB-C、J3 FPC 24P。
3. **LCSC 編號**：睇下屬性 `Supplier Part` / `LCSC Part` 有冇帶過去。冇嘅話，下 JLC 貼片前要逐粒重新揀 C 編號，或者換成立創庫嘅零件。
4. **J3 攝像頭排線方向**：腳序用 ESP32-CAM 排法（pin1=Y0）。上接觸／下接觸 FPC 座 pin1 方向相反，一定要對住你買嘅 OV2640 模組。
5. **GPIO45（LCD_CS）唔可以有上拉**（strapping 腳，被拉高會開唔到機）。
6. **電池 J2**：pin1 = +，買嘅電池紅黑線序要量過先插。
7. **原生 USB 用唔到**（GPIO19/20 畀 LCD 用咗），燒錄要經 CH340C，而且 SW3 要撥去 ON。
8. KiCad 入面每隻腳都係「短導線 + 網絡標籤」，冇用電源符號同 PWR_FLAG，所以匯入後全部都會係網絡標籤。

## 5. 驗證結果（KiCad 9.0.2，2026-10-06 HKT）
- ERC（全部嚴重程度）：**0 錯誤、0 警告**。
- 網表逐腳核對 `netdef.py`：307 隻腳，0 個問題。
- 對返 BOM（data.py）：每個位號同 LCSC 編號都一致；冇多、冇少。
- 對返 Pin Map：34 隻 ESP32-S3 模組腳嘅網絡名同符號腳名（IOxx）都啱。
- 冇得單腳網絡（除咗刻意打 NC 嘅 31 隻腳）。
- KiCad 5 版本：KiCad 9 嘅命令行工具讀唔到舊格式嘅符號庫連結，所以我用自己寫嘅腳本獨立核對咗連線（74 粒零件、276 條導線、276 個標籤，0 個問題），但**未喺 KiCad 5 本身開過**。

## 6. 已知限制
- 原理圖係自動排版：每個功能區一行，用網絡標籤連接，冇畫導線網，所以睇落比較「散」，但連接關係完整。想靚啲可以匯入之後自己搬位。
- 為咗 ERC 乾淨，我將工程符號庫入面所有腳嘅電氣類型改咗做 passive（原本 easyeda2kicad 出嘅係 unspecified／input），唔影響連線。
- 標準版文件話 KiCad 5.1.3 之後嘅格式可能匯入失敗，所以標準版用家請優先試 KiCad 5 後備包。
- 想改腳位：改 `netdef.py`，再行 `build.sh`，會重新生成兩個版本、ERC、網表同報告。
