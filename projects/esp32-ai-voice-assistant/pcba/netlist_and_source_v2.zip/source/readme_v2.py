# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt, Cm
from docx.oxml.ns import qn
doc = Document()
st = doc.styles['Normal']; st.font.name = 'Noto Sans CJK HK'; st.font.size = Pt(10.5)
st.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK HK')
H = lambda t, l=1: doc.add_heading(t, l)
def P(t, b=False):
    p = doc.add_paragraph(); r = p.add_run(t); r.bold = b
def B(items):
    for t in items: doc.add_paragraph(t, style='List Bullet')
def N(items):
    for t in items: doc.add_paragraph(t, style='List Number')
doc.add_heading('README：KiCad 原理圖 v2（加遊戲按鍵）匯入立創 EDA', 0)
P('更新：2026-10-06（HKT）｜腳位跟小智 bread-compact-wifi-s3cam，v2 加咗 TCA9554 遊戲按鍵')
P('⚠ 老實講：我冇辦法開立創 EDA，所以「匯入立創 EDA」呢一步未試過。檔案喺 KiCad 9.0.2 開過、跑過 ERC、逐條網絡核對過；塊板未做過、未測試過。', True)
H('1. v2 改咗咩')
B(['新增 U10 TCA9554PWR（C477924）I2C I/O 擴展，位址 0x20，掛喺攝像頭 SCCB bus（SDA = GPIO4、SCL = GPIO5，用現有 4.7k 上拉）。',
   '新增 R27 10k（INT 上拉）、C22 100nF（去耦）。',
   '新增 SW4–SW11 共 8 粒 TS-1187A-B-A-B（C318884，Basic）：UP / DOWN / LEFT / RIGHT / A / B / START / SELECT，分別接 P0–P7，另一邊接 GND。',
   'GPIO3 由「空」改做 BTN_INT（TCA9554 INT），J6 pin5 都改名 BTN_INT（只作量度用）。',
   '其餘 74 粒零件同 v1 一樣。'])
H('2. 檔案')
B(['ESP32S3_AI_Chatbot_KiCad6_for_LCEDA_v2.zip：首選。KiCad 6 格式工程（.kicad_pro、.kicad_sch、符號庫、封裝庫），85 粒零件全部連好。',
   'ESP32S3_AI_Chatbot_KiCad5_for_LCEDA_v2.zip：後備。同一張圖嘅 KiCad 5.1 舊格式（官方文件寫明支援 5.1）。',
   'ESP32S3_AI_Chatbot_schematic_v2.pdf：原理圖預覽（A1），右下角新增「GAME BUTTONS (v2)」一行。',
   'KiCad原理圖_net_report_v2.csv：76 條網絡逐腳列出，加 31 隻刻意 NC 嘅腳。',
   'ESP32S3_AI_Chatbot_netlist_and_source_v2.zip：PCB 用網表（PADS .asc、Allegro .tel、KiCad .net）、ERC 報告、KiCad BOM、生成原始碼。'])
H('3. 點樣匯入立創 EDA 專業版')
N(['路線 A（最快）：喺專業版開始頁揀匯入 KiCad（官方文件：「在专业版开始页进行导入」），揀 KiCad6 v2 zip。',
   '路線 B：路線 A 唔得就用 KiCad5 v2 zip 再試。',
   '路線 C：用官方「嘉立创EDA文件迁移助手」轉換（支援 .kicad_pro / .kicad_sch / .sch / .kicad_sym / .lib / .kicad_mod），之後喺立創 EDA「文件 → 导入 → 嘉立创EDA（专业版）」。',
   '路線 D：裝 KiCad，打開 .kicad_pro，用 KiCad 自帶歸檔（打包）功能整 zip 再試路線 A（官方文件要求用 KiCad 自帶打包）。',
   '只要 PCB：專業版「顶部菜单 → 文件 → 导入 → 网表」，可以試 PADS .asc 或 Allegro .tel（只會生成 PCB 零件同飛線，冇原理圖；未試過）。'])
H('4. 官方文件')
B(['專業版匯入 KiCad：https://prodocs.lceda.cn/cn/import-export/import-kicad/（寫明 KiCad 5.1、5.9）',
   '格式轉換助手：https://prodocs.lceda.cn/cn/import-export/easyeda-pro-format-converter/',
   '專業版匯入網表：https://prodocs.lceda.cn/cn/pcb/file-import-netlist/',
   '標準版匯入 KiCad：https://docs.lceda.cn/cn/Import/Import-KiCAD/'])
H('5. 匯入之後要檢查')
B(['零件 85 粒（包括 DNP：R21、R25、J6），網絡 76 條，用 net report 抽查，特別係 BTN_UP … BTN_SELECT、BTN_INT、CAM_SIOD、CAM_SIOC。',
   'U10 封裝 TSSOP-16（0.65mm 腳距）有冇綁定，pin1 方向。',
   'Supplier Part / LCSC Part 屬性有冇帶過去（例如 U10 = C477924，SW4–SW11 = C318884）。',
   '十字鍵 4 粒掣自己喺 PCB 擺成十字（中心距約 8–9mm），A/B 擺右邊，START/SELECT 擺中間下面。',
   'v1 嘅注意事項照舊：J3 FPC 方向、GPIO45 唔可以上拉、電池極性、燒錄要 SW3 ON。'])
H('6. 驗證結果（KiCad 9.0.2，2026-10-06 HKT）')
B(['ERC（全部嚴重程度）：0 錯誤、0 警告。',
   '網表逐腳核對 netdef.py：359 隻腳，0 個問題；冇單腳網絡（除咗 31 隻刻意 NC）。',
   '對返 BOM（data.py v2）：85 個位號同 LCSC 編號全部一致。',
   '對返 Pin Map：34 隻 ESP32-S3 模組腳（包括 GPIO3 = BTN_INT）嘅網絡名同符號腳名都啱。',
   'KiCad 5 版本：用獨立腳本核對連線（85 粒零件、328 條導線、328 個標籤、31 個 NC，0 個問題），未喺 KiCad 5 本身開過。'])
H('7. 韌體')
B(['官方小智韌體唔會讀呢啲掣，但亦唔受影響（攝像頭掃描唔包 0x20）。',
   '打機或者用掣控制，要自訂韌體；範例（ESP-IDF 同 Arduino）喺《設計說明 v2》5.11 節。'])
doc.save('out/README_KiCad原理圖_v2_遊戲按鍵.docx')
print('readme ok')
