# -*- coding: utf-8 -*-
"""Emit the SAME schematic (same placement/netlist as gen_sch.py) in KiCad 5.1 legacy format (.sch + .lib + -cache.lib + .pro)."""
import os, re, zlib
import gen_sch as G
from netdef import PARTS
OUTDIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "proj_v5")
os.makedirs(os.path.join(OUTDIR, "lib"), exist_ok=True)
NAME = "ESP32S3_AI_Chatbot"
def mil(v): return int(round(v / 0.0254))
def pname(n): 
    n = re.sub(r'~\{([^}]*)\}', r'~\1', n)
    return re.sub(r'\s', '_', n) or '~'
def lib_entry(sym, libname):
    e = G.SYMS[sym]
    props = {G.unq(x[1]): G.unq(x[2]) for x in e[2:] if isinstance(x, list) and x[0] == 'property'}
    refp = props.get('Reference', 'U')
    out = [f"#\n# {libname}\n#", f"DEF {libname} {refp} 0 40 Y Y 1 F N",
           f'F0 "{refp}" 0 300 50 H V C CNN', f'F1 "{sym}" 0 -300 50 H V C CNN',
           f'F2 "LCSC:{props.get("Footprint","").split(":")[-1]}" 0 -400 50 H I C CNN',
           f'F3 "{props.get("Datasheet","")}" 0 -500 50 H I C CNN',
           f'F4 "{props.get("LCSC Part","")}" 0 -600 50 H I C CNN "LCSC Part"', "DRAW"]
    def walk(x):
        if not isinstance(x, list) or not x: return
        k = x[0]
        get = lambda name: next((y for y in x if isinstance(y, list) and y and y[0] == name), None)
        fill = get('fill'); ft = 'N'
        if fill:
            t = G.unq(fill[1][1]) if isinstance(fill[1], list) else 'none'
            ft = {'background': 'f', 'outline': 'F'}.get(t, 'N')
        if k == 'rectangle':
            s, en = get('start'), get('end')
            out.append(f"S {mil(float(s[1]))} {mil(float(s[2]))} {mil(float(en[1]))} {mil(float(en[2]))} 0 1 0 {ft}")
        elif k == 'polyline':
            pts = [(mil(float(p[1])), mil(float(p[2]))) for p in get('pts')[1:]]
            out.append(f"P {len(pts)} 0 1 0 " + " ".join(f"{a} {b}" for a, b in pts) + f" {ft}")
        elif k == 'circle':
            c, r = get('center'), get('radius')
            out.append(f"C {mil(float(c[1]))} {mil(float(c[2]))} {max(1, mil(float(r[1])))} 0 1 0 {ft}")
        elif k == 'pin':
            at, ln = get('at'), get('length')
            nm, nu = G.unq(get('name')[1]), G.unq(get('number')[1])
            o = {0: 'R', 180: 'L', 90: 'U', 270: 'D'}[int(float(at[3])) % 360]
            out.append(f"X {pname(nm)} {nu} {mil(float(at[1]))} {mil(float(at[2]))} {mil(float(ln[1]))} {o} 50 50 1 1 P")
        else:
            for y in x: walk(y)
    for x in e[2:]:
        if isinstance(x, list) and x[0] == 'symbol': walk(x)
    out += ["ENDDRAW", "ENDDEF"]
    return "\n".join(out)
used = sorted({p[1] for p in PARTS})
hdr = "EESchema-LIBRARY Version 2.4\n#encoding utf-8\n"
open(os.path.join(OUTDIR, "lib", "LCSC.lib"), "w", encoding="utf-8").write(hdr + "\n".join(lib_entry(s, s) for s in used) + "\n#\n#End Library\n")
open(os.path.join(OUTDIR, f"{NAME}-cache.lib"), "w", encoding="utf-8").write(hdr + "\n".join(lib_entry(s, "LCSC_" + s) for s in used) + "\n#\n#End Library\n")
# ---- schematic
W, H = 33110, 23386
L = ["EESchema Schematic File Version 4", "EELAYER 30 0", "EELAYER END", f"$Descr A1 {W} {H}", "encoding utf-8", "Sheet 1 1",
     'Title "ESP32-S3 AI Chatbot (xiaozhi bread-compact-wifi-s3cam pinout)"', 'Date "2026-10-06"', 'Rev "0.2 (v2 game buttons)"',
     'Comp "Maker Bu Wan Ji Hua"', 'Comment1 "Auto-generated. NOT built or tested. Check footprints & FPC orientation."',
     'Comment2 "GPIO45 = LCD CS: NO pull-up (strapping pin)"', 'Comment3 ""', 'Comment4 ""', "$EndDescr"]
conns = []
for (p, ox, oy) in G.placed:
    ref, sym, val, lcsc, dnp, grp, pmap = p
    pins, pts = G.sym_info(sym)
    X, Y = mil(ox), mil(oy)
    ys = [q[1] for q in pts]
    top, bot = Y - mil(max(ys)) - 150, Y - mil(min(ys)) + 150
    props = {G.unq(x[1]): G.unq(x[2]) for x in G.SYMS[sym][2:] if isinstance(x, list) and x[0] == 'property'}
    fp = "LCSC:" + props.get("Footprint", "").split(":")[-1]
    ts = "%08X" % zlib.crc32(ref.encode())
    L += ["$Comp", f"L LCSC:{sym} {ref}", f"U 1 1 {ts}", f"P {X} {Y}",
          f'F 0 "{ref}" H {X} {top} 50  0000 C CNN', f'F 1 "{val}" H {X} {bot} 50  0000 C CNN',
          f'F 2 "{fp}" H {X} {bot+100} 50  0001 C CNN', f'F 3 "{props.get("Datasheet","")}" H {X} {bot+100} 50  0001 C CNN',
          f'F 4 "{lcsc}" H {X} {bot+100} 50  0001 C CNN "LCSC Part"', f'F 5 "{lcsc}" H {X} {bot+100} 50  0001 C CNN "LCSC"',
          f'F 6 "LCSC" H {X} {bot+100} 50  0001 C CNN "Supplier"', f'F 7 "{lcsc}" H {X} {bot+100} 50  0001 C CNN "Supplier Part"']
    if dnp: L.append(f'F 8 "DNP" H {X} {bot+200} 50  0000 C CNN "DNP"')
    L += [f"\t1    {X} {Y}", "\t1    0    0    -1  ", "$EndComp"]
    for n, plist in pins.items():
        net = pmap[n]
        for (px, py, pa, ln, nm) in plist:
            ax, ay = X + mil(px), Y - mil(py)
            if net is None:
                L.append(f"NoConn ~ {ax} {ay}"); continue
            dx, dy, orient = {0: (-100, 0, 2), 180: (100, 0, 0), 90: (0, 100, 3), 270: (0, -100, 1)}[pa]
            bx, by = ax + dx, ay + dy
            L += ["Wire Wire Line", f"\t{ax} {ay} {bx} {by}", f"Text Label {bx} {by} {orient}    50   ~ 0", net]
for (t, x, y) in G.texts:
    L += [f"Text Notes {mil(x)} {mil(y)} 0    100  ~ 20", t]
L.append("$EndSCHEMATC")
open(os.path.join(OUTDIR, f"{NAME}.sch"), "w", encoding="utf-8").write("\n".join(L) + "\n")
open(os.path.join(OUTDIR, f"{NAME}.pro"), "w").write("update=2026-10-06\nversion=1\nlast_client=kicad\n[general]\nversion=1\nRootSch=\nBoardNm=\n[eeschema]\nversion=1\nLibDir=\n[eeschema/libraries]\n")
open(os.path.join(OUTDIR, "sym-lib-table"), "w").write('(sym_lib_table\n  (lib (name LCSC)(type Legacy)(uri ${KIPRJMOD}/lib/LCSC.lib)(options "")(descr "LCSC parts"))\n)\n')
open(os.path.join(OUTDIR, "fp-lib-table"), "w").write('(fp_lib_table\n  (lib (name LCSC)(type KiCad)(uri ${KIPRJMOD}/lib/LCSC.pretty)(options "")(descr "LCSC footprints"))\n)\n')
print("v5 written")
