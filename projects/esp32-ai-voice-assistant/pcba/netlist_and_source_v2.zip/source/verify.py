# -*- coding: utf-8 -*-
import sys, os, re, csv, collections
sys.path.insert(0, '/workspace/pcba'); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gen_sch import parse, unq
from netdef import PARTS
import data
nl = parse(open('out/netlist/ESP32S3_AI_Chatbot_KiCad.net', encoding='utf-8').read())
comps = {}; nets = {}
for sec in nl[1:]:
    if sec[0] == 'components':
        for c in sec[1:]:
            ref = unq(next(x for x in c if x[0] == 'ref')[1])
            fields = {}
            for x in c:
                if x[0] == 'fields':
                    for f in x[1:]:
                        fields[unq(f[1][1])] = unq(f[2]) if len(f) > 2 else ''
                if x[0] == 'property':
                    fields[unq(x[1][1])] = unq(x[2][1]) if len(x) > 2 else ''
            fp = unq(next(x for x in c if x[0] == 'footprint')[1])
            comps[ref] = (fields, fp)
    if sec[0] == 'nets':
        for n in sec[1:]:
            name = unq(next(x for x in n if x[0] == 'name')[1])
            nodes = [(unq(next(y for y in x if y[0] == 'ref')[1]), unq(next(y for y in x if y[0] == 'pin')[1]),
                      unq(next((y for y in x if y[0] == 'pinfunction'), ['', '""'])[1])) for x in n if x[0] == 'node']
            nets[name.lstrip('/')] = nodes
problems = []
# 1. every PARTS pin assignment appears in netlist
pin2net = {}
for name, nodes in nets.items():
    for r, p, f in nodes: pin2net[(r, p)] = name
for ref, sym, val, lcsc, dnp, grp, pmap in PARTS:
    if ref not in comps: problems.append(f"missing component {ref}")
    else:
        f, fp = comps[ref]
        if f.get('LCSC Part') != lcsc: problems.append(f"{ref} LCSC field {f.get('LCSC Part')} != {lcsc}")
    for p, net in pmap.items():
        got = pin2net.get((ref, p))
        if net is None:
            if got and not got.startswith('unconnected-'): problems.append(f"{ref}.{p} should be NC, got {got}")
        elif got != net: problems.append(f"{ref}.{p} expected {net} got {got}")
# 2. BOM consistency: every BOM designator present w/ same LCSC
def expand(d):
    out = []
    for part in d.split(','):
        m = re.match(r'([A-Z]+)(\d+)-([A-Z]*)(\d+)', part)
        if m: out += [f"{m.group(1)}{i}" for i in range(int(m.group(2)), int(m.group(4)) + 1)]
        else: out.append(part)
    return out
bomrefs = {}
for row in data.BOM:
    if not row[6]: continue
    for rr in expand(row[0]): bomrefs[rr] = row[6]
for rr, l in bomrefs.items():
    if rr not in comps: problems.append(f"BOM {rr} not in schematic")
    elif comps[rr][0].get('LCSC Part') != l: problems.append(f"BOM {rr} LCSC {l} vs sch {comps[rr][0].get('LCSC Part')}")
for rr in comps:
    if rr not in bomrefs: problems.append(f"schematic {rr} not in BOM")
# 3. pin map cross-check vs data.PINS (GPIO -> module pin -> expected function keyword)
expect = {"MIC WS":"MIC_WS","MIC SCK":"MIC_SCK","MIC SD":"MIC_SD","SPK DOUT":"SPK_DIN","SPK BCLK":"SPK_BCLK","SPK LRCK":"SPK_LRCK",
          "CAM SIOD":"CAM_SIOD","CAM SIOC":"CAM_SIOC","CAM VSYNC":"CAM_VSYNC","CAM HREF":"CAM_HREF","CAM XCLK":"CAM_XCLK_MCU",
          "CAM PCLK":"CAM_PCLK_MCU","LCD SCL":"LCD_SCL","LCD SDA":"LCD_SDA","LCD RES":"LCD_RES","LCD DC":"LCD_DC","LCD CS":"LCD_CS",
          "LCD 背光":"LCD_BL_PWM","WS2812":"RGB_LED_GPIO48","LAMP":"LAMP_GPIO14","U0TXD":"U0TXD","U0RXD":"U0RXD","BOOT":"IO0","CHIP_PU":"EN","BTN_INT":"BTN_INT"}
checked = 0
for gpio, mpin, sig, *_ in data.PINS:
    if not mpin.isdigit(): continue
    net = pin2net.get(("U1", mpin))
    m = re.match(r'CAM D(\d)', sig)
    exp = f"CAM_D{m.group(1)}" if m else next((v for k, v in expect.items() if sig.startswith(k)), None)
    if gpio == "GPIO46": exp = gpio
    if exp is None: problems.append(f"no expectation for {gpio} {sig}"); continue
    checked += 1
    if net != exp: problems.append(f"U1 pin {mpin} ({gpio} {sig}) -> {net}, expected {exp}")
# also check symbol pin name matches GPIO number
for gpio, mpin, sig, *_ in data.PINS:
    if not mpin.isdigit(): continue
    fn = next((f for r, p, f in nets.get(pin2net.get(("U1", mpin)), []) if r == "U1" and p == mpin), "")
    want = {"EN": "EN", "GPIO43": "TXD0", "GPIO44": "RXD0"}.get(gpio, gpio.replace("GPIO", "IO"))
    if fn != want: problems.append(f"U1 pin {mpin}: symbol pin name {fn} != {want}")
# 4. single-node nets
single = [(n, nodes) for n, nodes in nets.items() if len(nodes) == 1 and not n.startswith('unconnected-')]
for n, nodes in single: problems.append(f"single-pin net {n}: {nodes}")
nc_nets = [n for n in nets if n.startswith('unconnected-')]
# report CSV
with open('out/net_report.csv', 'w', newline='', encoding='utf-8-sig') as fh:
    w = csv.writer(fh)
    w.writerow(["Net", "Pin count", "Connections (Ref.Pin[PinName])"])
    for n in sorted(nets, key=lambda s: (s.startswith('unconnected-'), s)):
        if n.startswith('unconnected-'): continue
        nodes = nets[n]
        w.writerow([n, len(nodes), " ".join(f"{r}.{p}[{f}]" if f and f != p else f"{r}.{p}" for r, p, f in sorted(nodes, key=lambda t: (re.sub(r'\d', '', t[0]), int(re.sub(r'\D', '', t[0]) or 0), t[1])))])
    w.writerow([]); w.writerow(["NC pins (no-connect flags)", len(nc_nets), " ".join(sorted(n.replace('unconnected-', '').strip('()') for n in nc_nets))])
print(f"components={len(comps)} nets={len(nets)-len(nc_nets)} nc_pins={len(nc_nets)} gpio_checked={checked}")
print("PROBLEMS:", len(problems)); [print(" -", p) for p in problems]
