import zipfile, os, shutil
def zipdir(zpath, base, items):
    with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as z:
        for it in items:
            p = os.path.join(base, it)
            if os.path.isdir(p):
                for root, _, files in os.walk(p):
                    for f in sorted(files):
                        full = os.path.join(root, f); z.write(full, os.path.relpath(full, base))
            else: z.write(p, it)
D = 'pkg_v3'
shutil.rmtree(D, ignore_errors=True); os.makedirs(D)
zipdir(f'{D}/ESP32S3_AI_Chatbot_KiCad6_for_LCEDA_v3.zip', 'proj', ['ESP32S3_AI_Chatbot.kicad_pro','ESP32S3_AI_Chatbot.kicad_sch','sym-lib-table','fp-lib-table','lib'])
zipdir(f'{D}/ESP32S3_AI_Chatbot_KiCad5_for_LCEDA_v3.zip', 'proj_v5', ['ESP32S3_AI_Chatbot.pro','ESP32S3_AI_Chatbot.sch','ESP32S3_AI_Chatbot-cache.lib','sym-lib-table','fp-lib-table','lib'])
with zipfile.ZipFile(f'{D}/ESP32S3_AI_Chatbot_netlist_and_source_v3.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for f in sorted(os.listdir('out/netlist')): z.write(f'out/netlist/{f}', f'netlist/{f}')
    for f in ['netdef.py','gen_sch.py','gen_v5.py','verify.py','verify_v5.py','build.sh','readme_v3.py','pack_v3.py']: z.write(f, f'source/{f}')
    z.write('/workspace/pcba/data.py', 'source/data.py')
    z.write('/workspace/pcba/v3work/JoystickTest/JoystickTest.ino', 'firmware_test/JoystickTest/JoystickTest.ino')
    for f in ['ERC_report.txt','kicad_bom.csv','net_report.csv','README_KiCad原理圖_v3_搖桿.docx']: z.write(f'out/{f}', f)
shutil.copy('out/ESP32S3_AI_Chatbot_schematic.pdf', f'{D}/ESP32S3_AI_Chatbot_schematic_v3.pdf')
shutil.copy('out/net_report.csv', f'{D}/KiCad原理圖_net_report_v3.csv')
shutil.copy('out/README_KiCad原理圖_v3_搖桿.docx', f'{D}/')
for f in sorted(os.listdir(D)):
    print(f, os.path.getsize(f'{D}/'+f))
    if f.endswith('.zip'):
        zz = zipfile.ZipFile(f'{D}/'+f); print('   ', len(zz.namelist()), 'entries; test:', zz.testzip())
