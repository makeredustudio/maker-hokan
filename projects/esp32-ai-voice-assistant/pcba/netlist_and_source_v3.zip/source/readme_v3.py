# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn
doc = Document()
st = doc.styles['Normal']; st.font.name = 'Noto Sans CJK HK'; st.font.size = Pt(10.5)
st.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK HK')
H = lambda t, l=1: doc.add_heading(t, l)
def P(t, b=False):
    p = doc.add_paragraph(); r = p.add_run(t); r.bold = b
def B(items):
    for t in items: doc.add_paragraph(t, style='List Bullet')
def N(items):
    for t in items: doc.add_paragraph(t, style='List Number')
doc.add_heading('README：KiCad 原理圖 v3（類比搖桿）匯入立創 EDA', 0)
P('更新：2026-10-06（HKT）｜腳位跟小智 bread-compact-wifi-s3cam｜v3 = v2 嘅十字鍵改做 1 粒類比搖桿')
P('⚠ 老實講：我冇辦法開立創 EDA，所以「匯入立創 EDA」呢一步未試過。檔案喺 KiCad 9.0.2 開過、跑過 ERC、逐條網絡核對過；塊板未做過、未測試過。v1、v2 檔案冇改。', True)
H('1. v3 改咗咩（對比 v2）')
B(['刪除十字鍵 SW4–SW7（4 粒 TS-1187A-B-A-B）。',
   '新增 SW4 = Alps RKJXV122400R 類比搖桿（C918854，THT）：2 軸 10kΩ 電位器 + 中間按下。端子 3 → 3V3、端子 1 → GND、滑臂 → ADC；4 支金屬腳 → GND；按下 a/c → JOY_SW，b/d → GND。',
   '新增 U11 ADS1115IDGSR（C37593）16-bit I2C ADC，位址 0x48，同攝像頭 SCCB 共用 GPIO4（SDA）/ GPIO5（SCL）：AIN0 = JOY_X、AIN1 = JOY_Y、AIN2 = 3V3（比例參考）、AIN3 → GND，ALERT/RDY 懸空。',
   '新增 C23（U11 去耦）、C24 / C25（JOY_X / JOY_Y 對地 100nF，Alps Fig.1 接法）。',
   'U10 TCA9554：P0 = JOY_SW（搖桿按下）、P1–P4 = A / B / START / SELECT、P5–P7 留空（NC）。',
   'A / B / START / SELECT 由 v2 嘅 SW8–SW11 改名做 SW5–SW8（同一款 C318884）。',
   '冇用多任何 GPIO；GPIO3 仍然係 BTN_INT。其餘零件同 v2 一樣。'])
H('2. 檔案')
B(['ESP32S3_AI_Chatbot_KiCad6_for_LCEDA_v3.zip：首選。KiCad 6 格式工程（.kicad_pro、.kicad_sch、符號庫、封裝庫），86 粒零件全部連好。',
   'ESP32S3_AI_Chatbot_KiCad5_for_LCEDA_v3.zip：後備。同一張圖嘅 KiCad 5.1 舊格式（立創官方文件寫明支援 5.1）。',
   'ESP32S3_AI_Chatbot_schematic_v3.pdf：原理圖預覽（A1），右下角「GAME CONTROLS (v3)」一行。',
   'KiCad原理圖_net_report_v3.csv：75 條網絡逐腳列出，加 35 隻刻意 NC 嘅腳。',
   'ESP32S3_AI_Chatbot_netlist_and_source_v3.zip：PCB 用網表（PADS .asc、Allegro .tel、KiCad .net）、ERC 報告、KiCad BOM、生成原始碼、Arduino 搖桿測試程式。'])
H('3. 點樣匯入立創 EDA 專業版')
N(['路線 A（最快）：喺專業版開始頁揀匯入 KiCad，揀 KiCad6 v3 zip。',
   '路線 B：路線 A 唔得就用 KiCad5 v3 zip 再試。',
   '路線 C：用官方「嘉立创EDA文件迁移助手」轉換（支援 .kicad_pro / .kicad_sch / .sch / .kicad_sym / .lib / .kicad_mod），之後喺立創 EDA「文件 → 导入 → 嘉立创EDA（专业版）」。',
   '路線 D：裝 KiCad，打開 .kicad_pro，用 KiCad 自帶歸檔（打包）功能整 zip 再試路線 A。',
   '只要 PCB：專業版「顶部菜单 → 文件 → 导入 → 网表」，可以試 PADS .asc 或 Allegro .tel（只會生成 PCB 零件同飛線，冇原理圖；未試過）。'])
H('4. 官方文件')
B(['專業版匯入 KiCad：https://prodocs.lceda.cn/cn/import-export/import-kicad/（寫明 KiCad 5.1、5.9）',
   '格式轉換助手：https://prodocs.lceda.cn/cn/import-export/easyeda-pro-format-converter/',
   '專業版匯入網表：https://prodocs.lceda.cn/cn/pcb/file-import-netlist/'])
H('5. 匯入之後要檢查')
B(['零件 86 粒（包括 DNP：R21、R25、J6），網絡 75 條；用 net report 抽查 JOY_X、JOY_Y、JOY_SW、BTN_A … BTN_SELECT、BTN_INT、CAM_SIOD、CAM_SIOC。',
   'SW4 封裝 SW-TH_RKJXV1224005（RKJXV122400R 共用）有冇綁定；KiCad 檔孔徑已改 Alps 建議值（電位器腳 Ø1.1、固定腳 Ø1.6、掣腳 Ø1.3、定位柱 Ø1.6 NPTH）。如果立創用返官方 C918854 封裝，孔徑會係 1.2 / 1.8 / 1.6 / 1.8。',
   'Alps「禁止走線區」：搖桿正下面中間唔好走線、打 via、放零件。',
   'U11 封裝 MSOP-10（0.5mm 腳距）pin1 方向；Supplier Part / LCSC Part 有冇帶過去（U11 = C37593、SW4 = C918854、SW5–SW8 = C318884）。',
   '佈局：搖桿擺左、A/B 擺右、START/SELECT 擺中間下面；C24/C25 貼 U11。',
   'v1/v2 嘅注意事項照舊：J3 FPC 方向、GPIO45 唔可以上拉、電池極性、燒錄要 SW3 ON。'])
H('6. 驗證結果（KiCad 9.0.2，2026-10-06 HKT）')
B(['ERC（全部嚴重程度）：0 錯誤、0 警告。',
   '網表逐腳核對 netdef.py：373 隻腳，0 個問題；冇單腳網絡（除咗 35 隻刻意 NC）。',
   '對返 BOM（data.py v3）：86 個位號同 LCSC 編號全部一致。',
   '對返 Pin Map：34 隻 ESP32-S3 模組腳（包括 GPIO3 = BTN_INT）嘅網絡名同符號腳名都啱。',
   'KiCad 5 版本：用獨立腳本核對連線（86 粒零件、338 條導線、338 個標籤、35 個 NC，0 個問題），未喺 KiCad 5 本身開過。',
   '新封裝（SW4、U11）用 kicad-cli 載入 / 出圖測試過。'])
H('7. 韌體')
B(['官方小智韌體唔會讀搖桿同按鍵，但亦唔受影響（esp32-camera 唔會試 0x20 / 0x48）。',
   '要用搖桿就要自訂韌體；ESP-IDF 同 Arduino 範例喺《設計說明 v3》5.11 節；Arduino 測試程式（JoystickTest.ino）喺 netlist_and_source_v3.zip 入面，已編譯通過（ESP32 core 2.0.17），未上機。'])
doc.save('out/README_KiCad原理圖_v3_搖桿.docx')
print('readme ok')
