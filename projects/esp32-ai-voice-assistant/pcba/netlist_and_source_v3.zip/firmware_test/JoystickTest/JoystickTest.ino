// v3 搖桿 + 按鍵測試（ESP32-S3，Arduino core 2.0.17）
// I2C：SDA=GPIO4、SCL=GPIO5（同攝像頭 SCCB 共用）；ADS1115 @0x48、TCA9554 @0x20、INT=GPIO3
#include <Wire.h>
const uint8_t ADS = 0x48, TCA = 0x20;
const int INT_PIN = 3;
const float DEADZONE = 0.08f;          // 中心 ±8% 當 0

bool adsWrite(uint8_t reg, uint16_t v) {
  Wire.beginTransmission(ADS); Wire.write(reg); Wire.write(v >> 8); Wire.write(v & 0xFF);
  return Wire.endTransmission() == 0;
}
int16_t adsRead16(uint8_t reg) {
  Wire.beginTransmission(ADS); Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return 0;
  if (Wire.requestFrom(ADS, (uint8_t)2) != 2) return 0;
  uint16_t hi = Wire.read(), lo = Wire.read();
  return (int16_t)((hi << 8) | lo);
}
// mux: 4=AIN0(X) 5=AIN1(Y) 6=AIN2(3V3 參考)；PGA ±4.096V、單次、860SPS、比較器關
int16_t adsSingle(uint8_t mux) {
  uint16_t cfg = 0x8000 | (uint16_t(mux) << 12) | 0x0200 | 0x0100 | 0x00E0 | 0x0003;
  if (!adsWrite(0x01, cfg)) return 0;
  uint32_t t0 = millis();
  while (!(adsRead16(0x01) & 0x8000)) { if (millis() - t0 > 5) break; }   // OS=1 → 轉換完成
  return adsRead16(0x00);
}
uint8_t readButtons() {                 // bit=1 代表撳緊；P0=搖桿按下 P1=A P2=B P3=START P4=SELECT
  Wire.beginTransmission(TCA); Wire.write(0x00);
  if (Wire.endTransmission(false) != 0) return 0;
  Wire.requestFrom(TCA, (uint8_t)1);
  return Wire.available() ? (uint8_t)(~Wire.read() & 0x1F) : 0;
}
float cx = 0.5f, cy = 0.5f, minx = 0.1f, maxx = 0.9f, miny = 0.1f, maxy = 0.9f;
void readRatio(float &x, float &y) {    // 比例讀數 0..1（除以實際 3V3，抵消電源漂移）
  int16_t ref = adsSingle(6);
  if (ref < 1000) ref = 1000;
  x = adsSingle(4) / float(ref);
  y = adsSingle(5) / float(ref);
}
float shape(float v, float c, float lo, float hi) {   // → -1..1，含 deadzone
  float n = (v >= c) ? (v - c) / (hi - c) : (v - c) / (c - lo);
  if (fabsf(n) < DEADZONE) return 0;
  n = (n > 0 ? n - DEADZONE : n + DEADZONE) / (1 - DEADZONE);
  return constrain(n, -1.0f, 1.0f);
}
void setup() {
  Serial.begin(115200);
  Wire.begin(4, 5, 400000);
  pinMode(INT_PIN, INPUT);              // 板上 R27 10k 上拉
  float sx = 0, sy = 0, x, y;
  for (int i = 0; i < 16; i++) { readRatio(x, y); sx += x; sy += y; delay(5); }
  cx = sx / 16; cy = sy / 16;           // 開機時唔好掂搖桿：記低中心點
  Serial.printf("center x=%.3f y=%.3f\n", cx, cy);
}
void loop() {
  float x, y; readRatio(x, y);
  minx = min(minx, x); maxx = max(maxx, x); miny = min(miny, y); maxy = max(maxy, y);  // 自動學習行程
  int jx = int(shape(x, cx, minx, maxx) * 100), jy = int(shape(y, cy, miny, maxy) * 100);
  uint8_t b = readButtons();
  Serial.printf("X=%4d Y=%4d  SW=%d A=%d B=%d START=%d SELECT=%d\n", jx, jy,
                b & 1, (b >> 1) & 1, (b >> 2) & 1, (b >> 3) & 1, (b >> 4) & 1);
  delay(20);                            // 約 50Hz
}
